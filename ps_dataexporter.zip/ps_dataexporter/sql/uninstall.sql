-- PS Data Exporter - Uninstall SQL

DROP TABLE IF EXISTS `PREFIX_pde_export_log`;
DROP TABLE IF EXISTS `PREFIX_pde_export_file`;
DROP TABLE IF EXISTS `PREFIX_pde_geo_map`;
DROP TABLE IF EXISTS `PREFIX_pde_export_job`;
